MASKSMP ABILITY HUD — FONT-FIX

De plugin gebruikt per ability een eigen bitmap-font: masksmp:hud_<mask>_<power>.
De bijbehorende JSON-bestanden staan in assets/masksmp/font en de 10-glyph spritesheets in assets/masksmp/textures/font.

De gebruikte fallbacktekens zijn gewone Unicode-symbolen (◇ ◔ ◑ ◒ ◓ ◐ ◕ ◖ ◗ ◆). Met de resourcepack worden dit de MaskSMP ability-iconen; zonder de resourcepack blijven er normale, gecentreerde symbolen over in plaats van private-use tofu-vakjes.

Belangrijk: behoud alle bestanden hud_<mask>_<power>.json en hud_<mask>_<power>.png samen. Verwijder ook de centrale ability_hud.png niet; die blijft beschikbaar voor compatibiliteit met eerdere HUD-layouts.

Na het vervangen van de pack: activeer alleen de gecombineerde MaskSMP-resourcepack en druk op F3+T om textures opnieuw te laden.

Galaxy 1.2.8: de drie HUD-sprites en de drie GUI-ability-iconen zijn vernieuwd met helderder paars/cyaan artwork. Het HUD-frame, de power-cijfers en de cooldown-bars zijn behouden.
