MaskSMP — GECOMBINEERDE RESOURCEPACK (FINAL)

Deze ene resourcepack bevat:
- Dinobeasts originele MaskSMP maskermodellen en maskerteksturen.
- De GUI-iconen en paneltiles.
- De aangeleverde Angel-wing sprite, opgesplitst in linker- en rechtervleugel voor de display-effecten.

NORMALE CARVED PUMPKIN
De itemdefinitie assets/minecraft/items/carved_pumpkin.json behoudt alle originele masker-CMD's 1001–1090.
Als een carved pumpkin GEEN passend masker-CMD heeft, valt hij terug op minecraft:block/carved_pumpkin.
Dit is belangrijk voor Minecraft Java 1.21.11 / pack format 75: de vanilla carved-pumpkin fallback is een block-model, niet minecraft:item/carved_pumpkin. Daardoor blijft de gewone carved pumpkin normaal zichtbaar zonder je maskermodellen te overschrijven.
De normale carved-pumpkin blockstate en blocktexturen worden niet overschreven.

PRESERVATIE
- Originele mask-modelbestanden en mask-texturen zijn byte-for-byte behouden.
- Geen Miner-, Hunter-, Angel- of Demon-maskerbestanden verwijderd of vervangen.
- Alleen de fallback in de carved_pumpkin itemdefinitie is gecorrigeerd; GUI-assets zijn erbij gezet.

GUI custom-model-data (PAPER): 2001–2014, 2015–2016 (Angel-wing helften), 2020–2034, 2040–2049.
Mask custom-model-data (CARVED_PUMPKIN): 1001–1090.

INSTALLATIE
1. Gebruik dit bestand als de ENIGE MaskSMP resourcepack; combineer geen tweede GUI-addon erbovenop.
2. Installeer via Minecraft Resource Packs of via je server resource-pack instelling.
3. Reload het pack met F3+T (Java) of herstart de client als textures vast blijven zitten.
4. Test op de Minecraft-versie die bij pack format 75 hoort, bijvoorbeeld 1.21.11.

De resourcepack levert alleen modellen/texturen. Voor de GUI-functionaliteit en bewegende Angel-wings is de bijbehorende MaskSMP plugin nodig.
