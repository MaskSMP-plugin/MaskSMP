MaskSMP — Custom GUI Resource Pack

Target Minecraft: Java Edition 1.21.11 (resource-pack format 75).

IMPORTANT: This ZIP is intentionally packaged with pack.mcmeta and assets/ at its ROOT. Do not select a ZIP that has an extra parent folder around them.

This is based on Dinobeast's supplied resource pack. All existing files under assets/minecraft/models/item/masks/ and assets/minecraft/textures/item/masks/ were copied byte-for-byte. No existing mask model or texture was replaced or removed. New UI sprites and item model definitions were added under assets/minecraft/models/item/gui/, assets/minecraft/textures/item/gui/, and assets/minecraft/items/paper.json / enchanted_book.json.

For the themed slot tiles and icon models to appear in plugin menus, use the matching MaskSMP plugin source update. The plugin must assign the custom model data values (2001-2014, 2020-2034, 2040-2049) to PAPER items. The original carved_pumpkin model-data dispatch and mask assets are untouched.

Some files in the original supplied pack contain the literal text PLACE YOUR PNG HERE even though their filenames end in .png. Those files were preserved unmodified as requested; items that reference those individual placeholder files will still show a missing texture until the real Blockbench PNG is exported for that specific mask/tier. This does not prevent the pack itself from loading.

Install: select this ZIP directly in Minecraft Options > Resource Packs or host this ZIP as the server resource pack. Ensure the game version is compatible with pack format 75.
