MASKSMP RESOURCEPACK — GUI MASK FRONT FIX 1.2.15

Deze update verandert alleen de weergaverichting van niet-Galaxy-maskers in de GUI/inventory.
- De GUI-transform gebruikt nu schaal [1, 1, 1] zonder 180-gradenrotatie.
- De bestaande GUI-hoogte/translation per masker is behouden, ook voor Miner.
- De head-transform, geometrie, textures, HUD, menu-assets en alle zes Galaxy-maskermodellen zijn ongemoeid gelaten.

Installatie:
1. Maak een backup van je huidige resourcepack.
2. Vervang de inhoud van je actieve pack met de inhoud van deze ZIP.
3. Laad Minecraft opnieuw met F3+T (of herselecteer het pack).

De JSON- en ZIP-structuur is gecontroleerd. De visuele render is nog niet live in Minecraft getest.
