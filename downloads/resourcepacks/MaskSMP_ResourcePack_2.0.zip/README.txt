MaskedSMP Resource Pack Template

Put your 32x32 or 64x64 PNG textures in:
assets/minecraft/textures/item/masks/

Example:
dragon_t1.png
dragon_t2.png
...
demon_t6.png

The custom model data values are:

Dragon: 1001-1006
Flame: 1007-1012
Shadow: 1013-1018
Storm: 1019-1024
Ocean: 1025-1030
Earth: 1031-1036
Ice: 1037-1042
Void: 1043-1048
Nature: 1049-1054
Warrior: 1055-1060
Speed: 1061-1066
Miner: 1067-1072
Hunter: 1073-1078
Angel: 1079-1084
Demon: 1085-1090


MaskSMP Galaxy Icons update 1.2.9: de drie Galaxy-powerillustraties en HUD-sprites zijn vernieuwd. De Galaxy-maskertextuur en -modellen zijn niet gewijzigd.
