MaskSMP Resourcepack — GUI Mask Front Fix 1.2.14

Dit is een volledige resourcepack, geen losse patch.
Alle oorspronkelijke bestanden zijn behouden. Alleen voor de 90 niet-Galaxy maskermodellen is de rotatie-context aangepast:
- GUI: 180 graden, voor de voorkant in menu/inventory.
- Head: teruggezet naar de originele transform, zodat maskers niet achterstevoren of achter op het hoofd komen.

Galaxy-modellen, textures, modelgeometrie, HUD-iconen en menu-indeling zijn niet gewijzigd.
