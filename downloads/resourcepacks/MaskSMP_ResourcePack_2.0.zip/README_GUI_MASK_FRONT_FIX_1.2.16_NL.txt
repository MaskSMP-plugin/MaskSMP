MASKSMP RESOURCEPACK — GUI MASK FRONT FIX 1.2.16

Deze update corrigeert uitsluitend de kijkrichting van maskers in het inventory-/GUI-itemvak.
- Niet-Galaxy-maskers: echte yaw-rotatie van 180 graden met positieve schaal [1, 1, 1].
- De negatieve Z-schaal is verwijderd in combinatie met de rotatie, omdat die de voor/achter-rotatie ongedaan maakte.
- De GUI-translation per masker is behouden.
- De head-transform, modelgeometrie, texturen, menu-iconen, HUD en overige assets zijn niet gewijzigd.
- Alle zes Galaxy-maskermodellen zijn byte-for-byte behouden.

Installatie:
1. Maak een backup van je actieve resourcepack.
2. Gebruik deze volledige map als je resourcepack, of vervang de packinhoud door de inhoud van deze ZIP.
3. Herlaad met F3+T of selecteer de pack opnieuw.

De JSON- en ZIP-integriteit is gecontroleerd. De weergave is niet live gerenderd in Minecraft in deze omgeving.
